package com.loginapp.service;


import com.loginapp.model.User;
import com.loginapp.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

    @Autowired
    private RegistrationRepository repository;

    public User saveUser(User user){

        return repository.save(user);

    }
    public User fetchByEmailId(String email){
        return  repository.findByEmailId(email);
    }
    public User fetchByEmailIdAndPassword(String email,String password){
        return  repository.findByEmailIdAndPassword(email,password);
    }
}
