package com.loginapp.controller;



import com.loginapp.ResourceNotFoundException;
import com.loginapp.model.Plans;
import com.loginapp.model.employee;
import com.loginapp.repository.EmployeeRepository;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;



import java.util.List;
import java.util.HashMap;
import java.util.Map;



@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class employeeController{



    @Autowired
    private EmployeeRepository employeeRepository;





    @GetMapping("/employee")
    public ResponseEntity<List<employee>> getAllEmployee(){
        return ResponseEntity.ok(employeeRepository.findAll());
    }

    @PostMapping("/employee")
    public employee addEmployee(@RequestBody employee Employee){
        return employeeRepository.save(Employee);
    }

    @GetMapping("/employee/{id}")
    public ResponseEntity<employee>getEmployeeById(@PathVariable(value = "id")int EmployeeId)
            throws ResourceNotFoundException{
        employee Employee=employeeRepository.findById(EmployeeId).orElseThrow(() ->
                new ResourceNotFoundException("plan not found for this id::"+EmployeeId));
        return ResponseEntity.ok().body(Employee);



    }

    @PutMapping("/employee/{id}")
    public ResponseEntity<employee> updateEmployee(@PathVariable(value = "id")int EmployeeId,
                                                   @RequestBody employee EmployeeDetails)throws ResourceNotFoundException{



        employee Employee=employeeRepository.findById(EmployeeId)
                .orElseThrow(()-> new ResourceNotFoundException("plans not found for this id::"+EmployeeId));



        Employee.setName(EmployeeDetails.getName());
        Employee.setLastName(EmployeeDetails.getLastName());
        Employee.setEmailId(EmployeeDetails.getEmailId());
        Employee.setMobile(EmployeeDetails.getMobile());
        Employee.setSalary(EmployeeDetails.getSalary());
        Employee.setLocation(EmployeeDetails.getLocation());
        final employee updateEmployee=employeeRepository.save(Employee);
        return ResponseEntity.ok(updateEmployee);
    }

    @DeleteMapping("/employee/{id}")
    public Map<String,Boolean> deleteEmployee(@PathVariable(value = "id")int EmployeeId)
            throws ResourceNotFoundException{



        employee Employee=employeeRepository.findById(EmployeeId)
                .orElseThrow(()-> new ResourceNotFoundException("plans not found for this id::"+EmployeeId));




        employeeRepository.delete(Employee);
        Map<String,Boolean>response=new HashMap<>();
        response.put("deleted",Boolean.TRUE);



        return response;




    }
}