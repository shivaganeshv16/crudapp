package com.loginapp.controller;

import com.loginapp.model.User;
import com.loginapp.repository.RegistrationRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="http://localhost:4200")

@RequestMapping(value="/api")

@RestController
public class RegistrationController {

    @Autowired
    private RegistrationRepository registrationRepository;

    @CrossOrigin(origins ="http://localhost:4200")
    @PostMapping("/registerUser")

    public User registerUser(@RequestBody User user) throws Exception{
        String tempEmailId = user.getEmail();
        if (tempEmailId!=null && !"".equals(tempEmailId)){
            User userObj =  registrationRepository.findByEmailId(tempEmailId);
            if (userObj != null){
                throw new Exception("user with " +tempEmailId+" is exist");
            }
        }
        User userObj= null;
        userObj =registrationRepository.save(user);
        return  userObj;

    }

    @CrossOrigin(origins ="http://localhost:4200")
    @PostMapping("/login")

    public User loginUser(@Validated @RequestBody User user) throws Exception {
        String tempEmailId = user.getEmail();
        String tempPass = user.getPassword();
        System.out.println(tempEmailId);
        System.out.println(tempPass);

        User userObj1 = null;

        if (tempEmailId != null && tempPass != null) {


            userObj1 = registrationRepository.findByEmailIdAndPassword(tempEmailId, tempPass);
            System.out.println(userObj1);


        }
        if (userObj1 == null) {
            throw new Exception("bad credentials");
        }
        return userObj1;
    }

}
