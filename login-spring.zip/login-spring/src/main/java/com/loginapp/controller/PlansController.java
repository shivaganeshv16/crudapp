package com.loginapp.controller;


import com.loginapp.ResourceNotFoundException;
import com.loginapp.model.Plans;
import com.loginapp.repository.PlansRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;




import java.util.List;
import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class PlansController {

    @Autowired
    private PlansRepository plansRepository;

    @PostMapping("/plans")
    public Plans addPlans(@RequestBody Plans plans){
        return plansRepository.save(plans);
    }

    @GetMapping("/plans")
    public ResponseEntity<List<Plans>>getAllPlans(){
        return ResponseEntity.ok(plansRepository.findAll());
    }

    @GetMapping("/plans/{id}")
    public ResponseEntity<Plans>getPlansById(@PathVariable(value = "id")int plansId)
            throws ResourceNotFoundException{
        Plans plans=plansRepository.findById(plansId).orElseThrow(() ->
                new ResourceNotFoundException("plan not found for this id::"+plansId));
                return ResponseEntity.ok().body(plans);

    }
    @PutMapping("/plans/{id}")
    public ResponseEntity<Plans> updatePlans(@PathVariable(value = "id")int plansId,
                                             @RequestBody Plans plansDetails)throws ResourceNotFoundException{

        Plans plans=plansRepository.findById(plansId)
                .orElseThrow(()-> new ResourceNotFoundException("plans not found for this id::"+plansId));

        plans.setPlanName(plansDetails.getPlanName());
        plans.setRental(plansDetails.getRental());
        plans.setSpeed(plansDetails.getSpeed());
        plans.setData(plansDetails.getData());
        plans.setLocation(plansDetails.getLocation());

        final Plans updatePlans=plansRepository.save(plans);
        return ResponseEntity.ok(updatePlans);
    }
    @DeleteMapping("/plans/{id}")
    public Map<String,Boolean> deletePlans(@PathVariable(value = "id")int plansId)
        throws ResourceNotFoundException{

        Plans plans=plansRepository.findById(plansId)
                .orElseThrow(()-> new ResourceNotFoundException("plans not found for this id::"+plansId));


        plansRepository.delete(plans);
        Map<String,Boolean>response=new HashMap<>();
        response.put("deleted",Boolean.TRUE);

        return response;


    }

}
