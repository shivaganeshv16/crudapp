package com.loginapp.model;



import javax.persistence.*;




@Entity
@Table(name = "employee1")
public class employee {



    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "lastName")
    private String lastName;
    @Column(name = "email")
    private String emailId;
    @Column(name = "salary")
    private int salary;

    @Column(name = "mobile")
    private int mobile;



    @Column(name = "Location")
    private String location;







    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;
    }



    public String getName() {
        return name;
    }



    public void setName(String name) {
        this.name = name;
    }



    public String getLastName() {
        return lastName;
    }



    public void setLastName(String lastName) {
        this.lastName = lastName;
    }



    public String getEmailId() {
        return emailId;
    }



    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }



    public int getSalary() {
        return salary;
    }



    public void setSalary(int salary) {
        this.salary = salary;
    }



    public int getMobile() {
        return mobile;
    }



    public void setMobile(int mobile) {
        this.mobile = mobile;
    }



    public String getLocation() {
        return location;
    }



    public void setLocation(String location) {
        this.location = location;
    }




}