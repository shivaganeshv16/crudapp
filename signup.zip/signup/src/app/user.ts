export class User {
   
    id:number;
    email:string;
    password:String;
   
   
    

    

    

    constructor(
      
    
       
        
    email:string , passsword:String)
        {
        this.email=email,
        this.password=passsword
       
        
        

        

       
        
        
    

        }}





