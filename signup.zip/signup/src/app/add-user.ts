export class AddUser {
   
    id:number;
    email:string;
    
    name:string;
    lastName:string;
    mobile:number;
    country:string;
    state:string;
    gender:string;
    department:string;
   
    age:number;

   
    constructor(
        name:string,
        lastName:string,
        mobile:number,
        country:string,
        state:string,
        gender:string,
        department:string,
        age:number,
        email:string )
        {
        this.email=email,
        this.name=name,
        this.lastName=lastName,
        this.mobile=mobile,
        this.country=country,
        this.state=state,
        this.gender=gender,
        this.department=department,
        this.age=age
        
    }

}





