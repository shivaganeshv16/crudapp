import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatSidenavModule} from '@angular/material/sidenav';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './MyComponents/login-page/login-page.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material-modules';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ProfileComponent } from './MyComponents/profile/profile.component';
import { AdduserComponent } from './adduser/adduser.component';
import { AboutComponent } from './about/about.component';
import { SignupComponent } from './signup/signup.component';
import { AddPlanComponent } from './PHASE2/add-plan/add-plan.component';
import { PlanListComponent } from './PHASE2/plan-list/plan-list.component';
import { UpdatePlanComponent } from './PHASE2/update-plan/update-plan.component';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    ProfileComponent,
    AdduserComponent,
    AboutComponent,
    SignupComponent,
    AddPlanComponent,
    PlanListComponent,
    UpdatePlanComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DataTablesModule,
    MatSidenavModule

   
    
    
  ],
  providers: [ 

    
  ],
  bootstrap: [AppComponent],
  entryComponents:[AdduserComponent]
})
export class AppModule { }
