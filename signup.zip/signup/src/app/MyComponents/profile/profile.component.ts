import { Component, OnInit } from '@angular/core';
import { MatDialog, } from '@angular/material/dialog';
import { MatDialogConfig } from '@angular/material/dialog';
import { AdduserComponent } from 'src/app/adduser/adduser.component';
import { AdduserService } from 'src/app/service/adduser.service';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
 

  constructor(

   ) { }
   
  
 

  ngOnInit(): void {
  }

}
