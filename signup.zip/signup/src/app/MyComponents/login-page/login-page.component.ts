import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators  } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { RegistrationService } from 'src/app/service/registration.service';
import { User } from 'src/app/user';
import { AboutComponent } from 'src/app/about/about.component';


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  loginForm: FormGroup;
  hide: false;
  user :User;

  msg='';
  


  constructor( private _service: RegistrationService ,
    private _router: Router) { }

  ngOnInit() {

    this.loginForm=new FormGroup(
      {
        email: new FormControl('',[Validators.required,Validators.email]),
        password: new FormControl('',[Validators.required])
      }
    );

  }
  onCancel(){
    this.loginForm.reset();
    
  }
  

  loginUser() {
    
    this.user= new User( this.loginForm.value.email ,
    this.loginForm.value.password )
                  

   this._service.loginUserFromRemote(this.user).subscribe(
     data => {
       console.log(data);
        if(data === null)
        {this._router.navigate(['/']);}
         else {
           console.log("logged in ");
       this._router.navigate(['/loginsuccess']);
      }
      
   },
   error =>{
     this.msg="Bad Credentials";
   }
  

   );
}

}