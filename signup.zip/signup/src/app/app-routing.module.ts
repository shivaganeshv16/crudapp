import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdduserComponent } from './adduser/adduser.component';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './MyComponents/login-page/login-page.component';
import { ProfileComponent } from './MyComponents/profile/profile.component';
import { AddPlanComponent } from './PHASE2/add-plan/add-plan.component';
import { PlanListComponent } from './PHASE2/plan-list/plan-list.component';
import { UpdatePlanComponent } from './PHASE2/update-plan/update-plan.component';
import { SignupComponent } from './signup/signup.component';


const routes: Routes = [
  {path:'',component: LoginPageComponent},
  {path:'loginsuccess',component:ProfileComponent},
  {path:'about',component:AboutComponent},
  {path:'signup',component:SignupComponent},
  {path:'adduser',component:AdduserComponent},

  {path:'add', component:AddPlanComponent},
  {path:'plans', component:PlanListComponent},
  {path:'update/:id',component:UpdatePlanComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
