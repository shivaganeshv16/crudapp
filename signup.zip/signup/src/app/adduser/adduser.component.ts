import { Component, OnInit } from '@angular/core';
import { AdduserService } from '../service/adduser.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import { Router } from '@angular/router';
import { RegistrationService } from '../service/registration.service';


import { AddUser } from '../add-user';
import {MatSnackBar} from '@angular/material/snack-bar';






@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  addUser:AddUser;
  msg='';
  msg1='';
 constructor(public service: AdduserService ,private _router:Router,
    private dialogRef:MatDialogRef<AdduserComponent>,
    private dialog: MatDialog,
    private _service:RegistrationService,
    private _snackBar: MatSnackBar
     )
  { }
  
  departments =[
    {id:3,value:'Dep 1'},
    {id:2,value:'Dep 2'},
    {id:3,value:'Dep 3'},
]
countries =[
  {id:3,value:'ind'},
  {id:2,value:' UsA'},
  {id:3,value:'aus'},
]

states =[
  {id:7,value:'ts'},
  {id:8,value:' mum'},
  {id:9,value:'che'},
]

  ngOnInit(): void {
    
  }
 
  
  onClear(){
    this.service.form.reset();
    this.service.initializeFormGroup();


  }
  

  onClose(): void{
  
    
    this.dialogRef.close();
        
        
      }

     
      onSubmitUser(){
      console.log(this.service.form)

      this.addUser= new AddUser( 
      this.service.form.value.name,
      this.service.form.value.lastName,
      this.service.form.value.mobile ,
      this.service.form.value.country,
      this.service.form.value.state,
      this.service.form.value.gender,
      this.service.form.value.department,
      this.service.form.value.age,
      this.service.form.value.email,
      
     
      )


        this._service.AddUserFromRemote(this.addUser).subscribe(
          data =>
          {
            console.log(data);
            console.log("responce received");
            this.msg="Added Successfully";

            this.dialogRef.close();
            this._router.navigate(['/'])
          },
          error =>{
            console.log("exception Occured  ");
            this.msg1= "User Already exist";
            
          }
        );

      }
}

