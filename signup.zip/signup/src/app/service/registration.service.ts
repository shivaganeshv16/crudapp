import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AddUser } from '../add-user';



@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http: HttpClient) { }
  headers = new HttpHeaders().set("Content-Type", "application/json");

  public loginUserFromRemote(user:User):Observable<any>{
    console.log(JSON.stringify(user));
    return this._http.post("http://localhost:8090/api/login",user,{ headers: this.headers });

  }
  public AddUserFromRemote(addUser:AddUser):Observable<any>{
    console.log(JSON.stringify(addUser));
    
    return this._http.post("http://localhost:8090/api/registerUser",addUser,{ headers: this.headers });

}
}