import { Injectable } from '@angular/core';
import { FormGroup, FormControl ,  Validators} from '@angular/forms';
 
import {  AngularFireList } from 'angularfire2/database';

@Injectable({
  providedIn: 'root'
})
export class AdduserService {
  AddUserFromRemote: any;

  constructor() { }


  adduser: AngularFireList<any>;

  form: FormGroup = new FormGroup(
    {
  name: new FormControl('',Validators.required),
  lastName: new FormControl('',Validators.required),
  email: new FormControl('',[Validators.required, Validators.email ,

    
  ]
  ),
  mobile: new FormControl('',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
  age:new FormControl('',[Validators.required,Validators.maxLength(2),Validators.pattern('[0-9]{2}$')]),
  country: new FormControl('0'),
  state: new FormControl('0'),
  gender: new FormControl('1'),
  department: new FormControl('0'),
 
 
 });

 initializeFormGroup () {
   this.form.setValue({
     name:'',
     lastName:'',
     email:'',
     mobile:'',
     country:'0',
     state:'0',
     gender:'1',
     department:'0',
     age:'',
    });
    }

  }

