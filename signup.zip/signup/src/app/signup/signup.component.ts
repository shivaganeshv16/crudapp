import { Component, OnInit } from '@angular/core';
import { MatDialog, } from '@angular/material/dialog';
import { MatDialogConfig } from '@angular/material/dialog';
import { AdduserComponent } from 'src/app/adduser/adduser.component';
import { AdduserService } from 'src/app/service/adduser.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(

    private dialog : MatDialog) { }
   
  onAddUser(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true;
    dialogConfig.autoFocus=true;
    dialogConfig.width="60%";
    this.dialog.open(AdduserComponent,dialogConfig);


  }

 
 

  ngOnInit(): void {
  }

}