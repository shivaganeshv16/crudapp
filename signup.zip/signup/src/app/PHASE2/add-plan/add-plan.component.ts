import { Component, OnInit } from '@angular/core';
import { PlanService } from '../plan.service';
import { Plan } from '../Model/plan';
import { FormControl,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-plan',
  templateUrl: './add-plan.component.html',
  styleUrls: ['./add-plan.component.css']
})
export class AddPlanComponent implements OnInit {

  plan: Plan=new Plan();
  submitted=false;

  constructor(private planService:PlanService,
              private router: Router) { }

  ngOnInit(): void {
  }

onSubmit(){
  this.submitted=true;
  this.planService.addPlans(this.plan).subscribe(
    data=> console.log(data), 
    error=> console.log(error)
  );
  this.plan=new Plan();
  this.router.navigate(['/plans']);

}
}
