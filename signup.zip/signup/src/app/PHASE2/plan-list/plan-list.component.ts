import { Component, OnInit , ViewChild } from '@angular/core';
import { Plan } from '../Model/plan';
import { PlanService } from '../plan.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { ApiResponse } from '../Model/api-response';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialogConfig } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';
import { AddPlanComponent } from '../add-plan/add-plan.component';



@Component({
  selector: 'app-plan-list',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.css']
})
export class PlanListComponent implements OnInit {
  plans:Observable<ApiResponse>;
  dtOptions: DataTables.Settings={};
  @ViewChild('dtOptions',{static:true})table;
  plan:Plan;
 
 
  

  constructor(private planService:PlanService,
              private router:Router,
              private dialog : MatDialog) {
                setTimeout(function(){
                  $(function(){
                    $('#example').DataTable();
                  });
                },2000);
               }


               

  ngOnInit(){
    
    this.plans=this.planService.getPlans();
    setTimeout(function(){
      $(function(){
        $('#example').DataTable();
      });
    },2000); 

  }

deletePlans(id:number){
  this.planService.deletePlans(id).subscribe(
    data=>{
      console.log(data);
      
      this.plans=this.planService.getPlans();

    },
    error=>console.log(error)
  );
}

updatePlans(id:number){

  this.router.navigate(['update',id]);
}

//

}

