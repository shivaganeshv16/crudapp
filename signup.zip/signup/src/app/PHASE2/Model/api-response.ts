export class ApiResponse {

    status: string;
    message:number;
    result:any;
}
