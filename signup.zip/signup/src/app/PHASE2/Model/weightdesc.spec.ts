import { Weightdesc } from './weightdesc';

describe('Weightdesc', () => {
  it('should create an instance', () => {
    expect(new Weightdesc()).toBeTruthy();
  });
});
