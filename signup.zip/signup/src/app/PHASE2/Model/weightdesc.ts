export class Weightdesc {
    constructor(public id:number, public planName:string){
        
    }
}
