export class Plan {
    id:number;
    planName:string;
    rental:number;
    speed:string;
    data:string;
    location:string;
  
  
}
