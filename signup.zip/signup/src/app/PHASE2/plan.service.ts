import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResponse } from './Model/api-response';
import { Plan } from './Model/plan';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class PlanService {

  constructor(private http: HttpClient) { }
  private baseUrl: string=environment.baseUrl+'/api/plans/';

getPlans():Observable<ApiResponse>{
  return this.http.get<ApiResponse>(this.baseUrl);
}

getPlansById(id:number):Observable<any>{
  const base = environment.baseUrl+'/api/plans?id=';
  return this.http.get(base + id);
}


addPlans(plan:Plan):Observable<ApiResponse>{
  return this.http.post<ApiResponse>(this.baseUrl, plan);
}

updatePlans(id:number,plan:Plan):Observable<ApiResponse>{
  return this.http.put<ApiResponse>(this.baseUrl + plan.id, plan);
}


deletePlans(id:number):Observable<ApiResponse>{
  return this.http.delete<ApiResponse>(this.baseUrl + id);
}

}

