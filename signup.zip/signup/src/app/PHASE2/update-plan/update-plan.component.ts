import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { Plan } from '../Model/plan';
import { PlanService } from '../plan.service';
import { ApiResponse } from '../Model/api-response';


@Component({
  selector: 'app-update-plan',
  templateUrl: './update-plan.component.html',
  styleUrls: ['./update-plan.component.css']
})
export class UpdatePlanComponent implements OnInit {
  id:number;
  plan:Plan;
  apiResponse:ApiResponse;

  constructor(
    private route:ActivatedRoute, 
    private router:Router,
    private planService:PlanService
  ) { }

  ngOnInit(){
    this.plan=new Plan();
    this.id=this.route.snapshot.params['id'];
    this.planService.getPlansById(this.id).subscribe(
      data=>{
        console.log(data);
        this.plan=data[0];
      },
      error=>console.log(error)
    );
  }
 
updatePlans(){
  this.planService.updatePlans(this.id, this.plan).subscribe(
    data =>{console.log(data);
   
    },
    error=> console.log(error));
    this.plan=new Plan();
    this.router.navigate(['/plans']);
  
}
onSubmit(){
  this.updatePlans();
}
list(){
  this.router.navigate(['/plans']);
}
}
